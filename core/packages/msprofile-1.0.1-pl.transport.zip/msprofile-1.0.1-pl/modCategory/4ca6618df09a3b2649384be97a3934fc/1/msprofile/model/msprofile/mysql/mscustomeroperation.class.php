<?php
require_once (dirname(dirname(__FILE__)) . '/mscustomeroperation.class.php');
class msCustomerOperation_mysql extends msCustomerOperation {}