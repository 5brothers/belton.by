<?php
class msCustomerOperation extends xPDOSimpleObject {}