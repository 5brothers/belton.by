<?php

$_lang['msprofile_prop_tplForm'] = 'Chunk registration form refill. You can use @INLINE chunks without calling filters and snippets.';
$_lang['msprofile_prop_tplPayment'] = 'Chunk to design a method of payment. You can use @INLINE chunks without calling filters and snippets.';
$_lang['msprofile_prop_tplOrder'] = 'Chunk clearance successful carrying out of the order. The default chunk of miniShop2 - tpl.msOrder.success.';
$_lang['msprofile_prop_sortby'] = 'What field to sort the output of the methods of payment.';
$_lang['msprofile_prop_sortdir'] = 'Sort direction: ascending or descending order.';
$_lang['msprofile_prop_limit'] = 'Limit sampling.';
$_lang['msprofile_prop_outputSeparator'] = 'Character to separate output, by default line break.';
$_lang['msprofile_prop_minSum'] = 'The minimum sum of replenishment of the account.';
$_lang['msprofile_prop_maxSum'] = 'The maximum amount to Deposit.';
$_lang['msprofile_prop_showInactive'] = 'Show inactive payment methods. The default is Yes, so you can use those methods that are disabled for payment in miniShop2.';
$_lang['msprofile_prop_payments'] = 'Id list of payment methods, separated by commas. If you specify an id with minus sign, then the way will be excluded from the query.';

$_lang['msprofile_prop_id'] = 'User id for output profile, if not specified, the output current.';
$_lang['msprofile_prop_tpl'] = 'Chunk for the registration of the conclusion of the user profile. You can use @INLINE chunks without calling filters and snippets.';