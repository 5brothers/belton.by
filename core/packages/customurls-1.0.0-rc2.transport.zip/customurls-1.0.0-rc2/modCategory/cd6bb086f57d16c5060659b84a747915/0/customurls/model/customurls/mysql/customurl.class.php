<?php
require_once (dirname(dirname(__FILE__)) . '/customurl.class.php');
class CustomUrl_mysql extends CustomUrl {}