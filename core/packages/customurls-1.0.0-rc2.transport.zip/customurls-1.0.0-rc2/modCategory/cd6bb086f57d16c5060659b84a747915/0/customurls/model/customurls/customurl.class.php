<?php
class CustomUrl extends xPDOSimpleObject {}