<?php
    $_lang['all'] = 'Все';
    $_lang['revaluation'] = 'Переоценка';
    $_lang['minishop2'] = 'miniShop2';
    $_lang['revaluation.management'] = 'Управление переоценкой';
    $_lang['revaluation.revers'] = 'Отмена переоценки';
    $_lang['revaluation.revers.desc'] = 'Для отмены операции удалите ее из списка';
    $_lang['id'] = 'ID';
    $_lang['comment'] = 'Комментарий';
    $_lang['time'] = 'Дата';
    $_lang['rev_dir'] = 'Изменение цены';
    $_lang['percent'] = 'Процент';
    $_lang['category'] = 'Категория';
    $_lang['remove'] = 'Отмена переоценки';
    $_lang['remove_confirm'] = 'Вы уверены?';
    $_lang['not_loaded_class'] = 'Класс msRevaluation не загружен';
    $_lang['new_revaluation'] = 'Новая переоценка';
    $_lang['buti_prices'] = 'Округлить до (руб.)';
    $_lang['help'] = 'Помощь';
    $_lang['help.text'] = file_get_contents(dirname(__FILE__).'/help.html');
    $_lang['increase'] = 'Увеличить';
    $_lang['decrease'] = 'Уменьшить';
    $_lang['empty_grid'] = $_lang['revaluation.desc'] = 'Чтобы выполнить переоценку кликните правой кнопкой мышки на таблице и выберите "'.$_lang['new_revaluation'].'".';
?>