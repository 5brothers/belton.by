<?php
require_once (dirname(dirname(__FILE__)) . '/mseintro.class.php');
class mseIntro_mysql extends mseIntro {}