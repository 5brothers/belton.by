<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6d2593fce985aed48d740ee862bac1a4',
      'native_key' => 'core',
      'filename' => 'modNamespace/cc0e69e13bdbb6bb4208cd9e3737cfe7.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '5138524154c5690cb0f912ac7b587750',
      'native_key' => 1,
      'filename' => 'modWorkspace/341935824ac5a49a169e4bf2ad6262ff.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'c46c7f07c216e5db203394702aee3c52',
      'native_key' => 1,
      'filename' => 'modTransportProvider/96726e130434faad67c671059998194b.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '97a7219e7f706b7d018da0f04fa9a6fd',
      'native_key' => 'topnav',
      'filename' => 'modMenu/ec818de3824675467dd51055957109df.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '17c0fe43fbf5bfd5df6feed29629c62e',
      'native_key' => 'usernav',
      'filename' => 'modMenu/8fd1ec2d66b03fbfb5ccd37f86baeb9f.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '4e04faac0116326f3d3d40c88cfce7aa',
      'native_key' => 1,
      'filename' => 'modContentType/a9dd252fb6720d65d3a2a032cfe70890.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b42c8c5757901aa18c93377e83b166bf',
      'native_key' => 2,
      'filename' => 'modContentType/6325bc56a2272225f0afa8c5110cb16b.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'fa8de78faa0ba6a3dd75e7f2caf4f2a3',
      'native_key' => 3,
      'filename' => 'modContentType/9153e8dfa3006aa3ecc7e53bbe3271f9.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '5e9f06667b0015246600c160bedcbeb3',
      'native_key' => 4,
      'filename' => 'modContentType/6cd2026d731a81176c34a1be8abeb7e5.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '0b8fbc7c946e5bb4896b78644b8281ab',
      'native_key' => 5,
      'filename' => 'modContentType/831202b4d44eebd8f1fc8662aaed81ae.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '882897de3c15d32f815df93fe2557fb5',
      'native_key' => 6,
      'filename' => 'modContentType/bfc3ff3199a6006891e7ce6f85400436.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '1f85b989b708a1b335055f3550fdb0cd',
      'native_key' => 7,
      'filename' => 'modContentType/1fc2248820898cf6c9a10f2f7f5c6191.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '16d31c83144ab1eaff91aad637798566',
      'native_key' => 8,
      'filename' => 'modContentType/3eb21d5fceed86033e537e5eb9e30e14.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e43c2d0e3baaaca1ea92ea0ab5f74e4f',
      'native_key' => NULL,
      'filename' => 'modClassMap/9e18a9a8bdcfa1100ca2117a127927f5.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '3b1f71f05f0924a6c2d6fd01d9462e06',
      'native_key' => NULL,
      'filename' => 'modClassMap/bf4ce5354d0005c7b96490396ba8466d.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'fb067fa3c7a690dfbd16c49d2bcf3163',
      'native_key' => NULL,
      'filename' => 'modClassMap/02657a2612422fd330bdf4750c3697de.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'af285bb383153ea130bc0ad4c50a39ee',
      'native_key' => NULL,
      'filename' => 'modClassMap/a484142e7155d432588e23c4e7601959.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'b0dc0f30a78c8d2e5b0e5481ff7608df',
      'native_key' => NULL,
      'filename' => 'modClassMap/cc2ed76795da4bbd10b9ca19aab0664f.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e974b4c0d32ea0a467f360b98783868b',
      'native_key' => NULL,
      'filename' => 'modClassMap/910eed3dedf77a1950519a74fc715790.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f91498d28c62880bf4b67329ed15048f',
      'native_key' => NULL,
      'filename' => 'modClassMap/372e7804bf8dc75d2197dcc11c30cbde.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7c0f670adcc6a7af5046aadece96539f',
      'native_key' => NULL,
      'filename' => 'modClassMap/9946602ee4c1c5da86a008a7d6c8a9e8.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '25beaadbf7154ee1f9dae117fb9132ad',
      'native_key' => NULL,
      'filename' => 'modClassMap/bc31cb764c90d524cc3bf7f6e5f8a38b.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f7df6af0b5e98851e456b65dd9b6c84',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/b051bde8091dd5afa1fa292bcea264d3.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9ad9ad22d582110a8b9644740ad0c2b',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/ef267b22b3ac882e2c6856fef185fcb3.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25b9b80bfa2351340633be914eca9982',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/5ca966102cc53cdae6736051b2c4402c.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30d9cb6a6228dec5ad0bf03a13032fe0',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/9f2e7170d6b3fccbd00d2d9762fb7bed.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f245856f24cb0c33affc6f5063043a2f',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/2765d1a655cb734cecbb9b11b810a581.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f1d3f0b2abd257b49fe528bbea65076',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/0f5703cd47d25e0cb45c6b4a0ad8ddf6.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '26a2cfefc219cf996aa778b9fb60df44',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/8573288e2d9920a73f16c1fe911da080.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd05cfb98f6c1da260efd05134db9dbed',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/b4bad98739ae1ed374c3908f9fb46e13.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36f32ab692096b969a4ba2321abb39c4',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/34d0a4f0d207b6550580e103be44de42.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d61886b0703f165a986fe044d594489',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/9a7e396e431527984f634b49ea496fb6.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2ad8e251c16d5c3b2060c8a30133e9b',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/e0beb0f7ee2e59864fdca7f53a505be8.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7bc3ba03a2ccc25eb9e0e803b962c207',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/aa967f0726f340dbe915fd7715b7389c.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fff06869703a8a1a426a220b74b8780d',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/fb805235d81e5fc26b349361d6d3be18.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f89f773d494bcfff7974e24dbf76d3d6',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/1d195db02d880cc3de9bf255e4358876.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4def3e81405c9d834fe493d1641769ea',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/7954d50d53ed4950aaddbe938523087f.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '981c0ab0eb27599949978f71f7dbe61c',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/01d8e19ac7f160dd9fefd5304bb6eac5.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32ac460bb519673e8977f5f083e833c2',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/bc9be077dcad9fb825f4d7cf4081b431.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f8103ff5ee6ee98d09df9e97f964c3c',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/93fc72ced093e3c58e93b4e16ade223e.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55e879d0c02748fab4173a1eef799084',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/7aa23d62c25dbe85c4ed4c892c94048c.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37422f9f50ec772391eb8586b59cbffd',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/d1e7164b2008d217980e6e1a2617b3e0.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '497bd850335b9f97dab4d521497841fc',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/a694d0e990719aed6fa723c1b2edbdcc.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '480b8a55ba336f4eb6c179d9f562f62b',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/5f84b414f00fef40ca162c8fb2b9a7fd.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '13e9a698500c07dc188ce58029dab373',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/88be88cd615abc6e6bdca88a5702ae65.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '792e0eabb8b3453652c975bdd55ae682',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/4067d3eaafe914670a71ac533d2b9b26.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a796f1ebc70f8cf05e396b3466a06ed',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/83a74f5a14ef569f8b3301b22bdfe160.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a981378e46c3c854ede4dbff8c5532e',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/30a3c5a047e24a0fd340c3d082d09e90.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2cd93914746f31b743bb443c3596e93a',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/7a5d95c6938c2189953912e0b7270c86.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc83a6e2f607c2376151d48a21c8bab0',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/8fa58d96739d387c0791425f82cdf083.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '684ee1e17dd0175cc6ca6fb109b7ae05',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/fd5b088c121c0d1117626f615393fe47.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e8eb7ead8af6be8cf816cfc7b28158f',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/e5d22222dd733e11040444a5cf761387.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '08b59442cb1e2198e15e3ec4b9daed97',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/11885ade71a05825578da864fe16ceaa.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c206db110f222c40c18c39bd7e357b5',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/45849666abde2332c3456f2fe6db9d1e.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfd5ab75c6f07f481673b50addf06c6c',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/915868f669ec9fea0ca8aa0c4f3372f1.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '656f49d8b7e05d8d4a62fd05519c4a19',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/2b0c307c121d7c8eeecb40ac0b51f938.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54531bef923a347e1cb75f394eb6200c',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/b8789e7318b16fc277cf8e96921362b0.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e401468af1ad38d819c2528ddd8b02a',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/3136cdafdde84f3053659cf926e8179c.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3aa4e9ef2292c506e7d1487c536a1ce9',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/0e0f44be7f99220f12ba6153a6c123ef.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40596af38d7fd4d33acdfb1541e51bdf',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/f63fd51692667db2d597a04d8e62dbfc.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd442a85f87252bd1ac5340fce9c248e1',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/d9a1f1509fb5c447cce5fac8f4d18bc4.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7548ef7006c1b08a48ffb64c09a025b5',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/ef2ff67d60308764374d5e9b15df0836.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4dadc778abb930df7105677b04653031',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/5e50f297f71505f88d7cb75e1bffdf34.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a99bf458447dbbbbe1f56d109571f4c',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/ca4df1cbdbfdd91652494c5c371edad3.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'faa8260424d61cf867d346049481140b',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/d5dc77a6be9adfb70bee43c71f2fbf68.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '92e1f0336125c66cffab8dfbd543d693',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/c5204d9be689f4d311de13e17af2806a.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d713326a8d7f1e75fba6e765a7e16d9',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/06148bdb0ab47b5ab60d65518798c30f.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab06f88e78b28fd4d26ed9216f087f06',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/157c672b48523f23c069b44bc0979d1d.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05229616e7d4ce0b4767def854f86fbe',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/9fc7d7e0ff125319fa7c48341a7504c6.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0856a30bc80f92c6e746e7ed688fc61',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/e3a34c3c7d13d9f48428f6db218f5f7e.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7701c8b73673da8697bda727be2805a7',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/3563d3a0254d43d6d97761b3c83ab25f.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '748ea09f592c87e68e348e8e64a8895b',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/e9c2d2ca211c6627bab80465ee7f0e40.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '82d8544ba4b642aca9fbd566b2328902',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/04b5a5d39b2198939ffbfe2b4a44d4bc.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3431045c97a0a112449f7817626f3b40',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/c30bb17871e29a7edc1550779994db66.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f201ad0738be8ca355709b9e3899565d',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/8f5cf7df16d9b0ff87b3b1b29c6b1aef.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ceea83fe074e35a74e82736a0345d259',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/f42a2297e86a269a09a0a96d233b43da.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1218edcb2bef5e2f7915e5590142363',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/638349e57b7e9869bf9198dd99906f34.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '513c954788fbb06c21b59a04255d6e39',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/1589e9de1950cc8f25b00255d7332d09.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8c9c281c4ba635287a3b9d0366aee98',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/13170225d2226942c8a36daa42832fb6.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc4a0bb172e83e17e7d8299a377ba97b',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/d81d3aaa6fe57e180ef000a909106b21.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd5bba6ad188b5edf83dccada26d71e4',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/cef6f2a52a84b963a644a2f74851ef5d.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'befe7af9e319773d2980edfab2d517ba',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/3de471df6f0b370c02bbe97226d6f002.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbceb824b4ed682eadec6b3095c23fc8',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/2f5cfeab6a50cace10c23b6d5543b625.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '782e200aa4568ba9ec418c670ba7962e',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/8d177f86e4e4d1620b467270d64eb3cd.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21db0bf91930da5f5e1bbf40493bfdbd',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/12e921a18eff9b5e308e07c475d564a6.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e46c1f9a0fd942fcda20eb85f99609f',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/5e8b0a9657e3f5a8fc4eb1a1825518be.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab05d0ab1e15d9cc9cbdae72dcadc94d',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/26bbdce541555512e07fd9c69521071c.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae10babf07fc4ad95897bdbb8d63e9c6',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/9c00e34bf19534b70a861fbe0098c81e.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e588c95a1b52e40bef2e9132a10d5a12',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/79ade56cc7066e5841d3425380f2df0f.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '00431fb81aff991f33bc5ecb4057b98a',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/4c64579b74fdfff4de1fd95495e37760.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbf756e7bc42dc28fafbe67edb4985e9',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/49e58134a6c9af5822a1c5a38e8d68e6.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3543f6b234f94636211ed142206e33aa',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/cf0207d1a4c29685fad02752adc293d5.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e489a84aa1b4afb9020b4b83dba1af6',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/8347dfd9d0ffc78070bb9060cf6a23c1.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ee3e6de4a207ad7a457e4a15d364d3c',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/8e5d4fd17139c0464b5df27d2575272f.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2aabeb5327008d45495ba39071b4bb7',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/283a5ad438703535c27af5ec53f62b64.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e700b333329456b371f7b31d9519a92',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/057a3cfd0526f4b1ad37e6d96e724d4f.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f8ba241ddcb51e61469ee26cb918e8c',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/7bcb40879d642cc14a5ba1af781796e3.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad511717a90e444cb33de0733fc50c9e',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/37a54dd3893dfd6693db3edc2fd20585.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48af99d4339280d6faf30293e23d1c75',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/8c7737d6aef24595b08b3f3d9d02db8d.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb2fccd3e366d0e4143f4142473933a0',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/64385ef53a9c14176b9646a8e07a8318.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1bada10d560e1d1b47f05d41e253344c',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/32cad8a921b6a45df1eb2be1cfe71bf0.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '350efa10febcf3256f1f3a8cc05cd015',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/c1532114c2f7c24a3e7cbb449ce7e801.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bbe00d84f859ddafc462a149c68d8f2f',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/29a7f82548896d5f92160bfaa07a549a.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8088d8e88f832fff7edfaa8efb65dca0',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/d47a9297f4217bc5ad5662c7c31b0efa.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '593cd9c0bf4d5ab91017f5a27a0ac9d5',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/1d7661d3baa06368c5575bbba5bc8d80.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '82fe14132bc2ec6510399eb86e101bfc',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/2e6575c07825c96a37b89290646987c0.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '256672bc1ef159a120484d6c02b280fd',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/865f4e834ad384b7d435a8b62e1d6df9.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec0556f93dd38156f38676758cd624fb',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/a59102cc13c4041c018a85f7a7f4d22c.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b35a6a4e1a0ca219bbac8a5dd874ef69',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/687dbca249770e7e16d75f6b0ef2985e.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29c2b42728b2e445270dc1392168b2ce',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/874d42d418bb9cbc84e0fb272dff184b.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '538938526c56faaa7a6dff24149d1cf0',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/23ee9cd0e68a2ed3418e11309e10a826.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8bdada0aa2b330241f15da725068b619',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/daf9443c7bce27249a2b65af06a1c168.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c53f4f460845aca5f338a4f60a6fa522',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/a8d5dc60e4f52535b759b59ed0c862e8.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd873f5c6a1374563993c4979f2b241e',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/50e66c37164282eadf4044cd31b0b746.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9eeda3d833d9f706655576b89f8861ec',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/ed22b8d5cd050f14d0cf3035e02d682f.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '918818f16bc4d7ccc073c8a1fc1e495c',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/aac3795983b1b3dfe40927104bdab9c7.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '209b1f1ded1877e84f512445f05c70cf',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/1922ca7a4cde6367d1aa6340c3b77649.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80aae246195595490d86898020a4698c',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/810111dc745a29c3f613aae84818d7f7.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c311464fd9e57e717dc92c4755d9d8e8',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/e01c9be0709b71d6b786df99ae6a7a4c.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27ae9e3d2f24d391c91185aeb27d7cd1',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/012d3c057bbf4537f64d25237288fe8a.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd85ed9eb158487a979da616a7f82d969',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/d158f04e6b8c010e09b8d0bd0579ab1f.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d2f15de14b482d780cea0b1d6684fd9',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/00a2cf9b40b82ee9aeec502bb9d7a0b3.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0279ec6e666dd29a8dcc31cd0aa7b888',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/e9fdf676ab3f59ffecd6256e7e90a214.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0651aafa6c8bdc1b2e35dea98facc41a',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/d871e9df7fb5720d770a5bca74a6e215.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43d370bf680c2b77f5a1fa40a4bdd367',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/ae1b1fd2d377ca23065375b2af036597.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74bc7a44eee60fd39bde9dfa3a080590',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/99ea325542b24ac6725f624d2f79df55.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96e2112c76101cb690aaf602eee2fd7d',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/ed8cf17076b9dba298a8882b5d576f5f.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '871f672d0cd921233ac38a20927844a0',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/2441fd844fc4f642d043869a18e8cc19.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a41ef7769ce71cda040ef13910f0bb1',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/bd4505eb5985a5e2345089e9eca317b2.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0bd5a62b35c8b8868c51385bd0e2ae4',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/a7435eaeb12791d184ceb0352ce5b7a2.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8768ee64a1b971ecf0f1bd2556dd40c0',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/5489d1d9e0852af5be16b6d6f5175113.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '570d6ef63c2223f0dcd270f8432639d1',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/5cd2d6dba8d17ad507772591ca23bd2c.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '473681a15a2b3efa905806b1dc264b5c',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/7dd7770156dd8443ff8ab893b3234637.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'efcd63f05297ee4b696d56e45a1bda5d',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/4323ccce6084f697834383a7de7e459d.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b56c191573e24d7f3702f29d579ce47',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/162d6416412f79fc27c5ddecdf7c6afb.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '113bef2b20d46d48f3408bab4d3b60f1',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/abbbc6a813e0452f269da61a8cdfa73e.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16afc9d9ae8d8005cfeaf1b418240a5d',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/25e889d399806fdd5f8a8106c75ded56.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8ded7735a3c2f7f5364bff45bc71ae7',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/333992a04c4e0aeef00cc9c076b5fa1a.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5575f77f0a3c2b606875102fa03d692a',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/54fe5415233055157a5b71cdacff1107.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c548b54c4a83b8c2b87c93165232361c',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/df70c9b6794031a3673854377eeb9e07.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c8c6331886c559066dd421bd1ae4eb2',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/413209abf87d4a6d5f02462ec01e4974.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a9d8df5be238328cf6350e02d7188bbb',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/34c6eb8f0d23283849c90f079eefca04.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d99a965705919e9cdf146b2e94f3f07',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/edcd406924e859bbd58cc59ffdcee406.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48f2d8ff791cff599e6da289852f6f42',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/52df50635e3110fe473f3a65b8e72989.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3af3fd88a1cdac51469b9222d662d574',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/44013fbdf3d54c0bd2c0c5314d322639.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7d1decc5162756a78a30088cef63d8a',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/bf7a33202818a46255d080d05270bd8f.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dab65871efb4c8f9589d7552989fbbd4',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/960212561e46f9e557f305feb408cfff.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3749952167a5eadea9fcafbbecae3022',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/3189a1db2870b7e342c4b50e13c09c50.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd78299c46fc64f42252462a78290bacf',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/14ff2f0ea3ef3b4e82d2bebe416e6ee4.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb5588872a81dc3c916d76e6547fad56',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/b039c56acf204b3affe36407abd49524.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '34138aca62c479de193b09348da7ae1d',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/8dbf3e92e7eccfb61e54a45d16894f5b.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb5cec0bfeee66b5c985e2f6b7838ab2',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/923ba458329e543e8c890ee36485f266.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '01badee621fd6f529e19c017ad9dcd7b',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/0cf7902c189acda5111c97c7bb9b19b6.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19fcb292ca1770e5a66e7c74a05c7483',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/50611937acc0e31ec050ccf0072bf5f6.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a4e7f84e6e7e007bb9f1e7c64883946',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/0590851946b74ddde99248ac88e83fb9.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c43edfcdf20dca07216d4ab878ab67e7',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/2a198f32f485cb8b5e59a677c708da61.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28f64798101b37cffa8ca87932768310',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/fff205fa14ce8429f50ab681d5b7a893.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6054902638a34bbad04e8febfff755c',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/5e1f023e8541751c3e8c3fc70625118d.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '87d0d8a9b626237158e5e9bfc8b588eb',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/1fb4a9dddf69be8f67f290b88e866d06.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6cd9643dbcb59fe571cc0bcdc9d87ef6',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/0bd6455e8beccc3cf3363a9771064490.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '980ce43193489a2ac9aab38d4060ff72',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/a46fcabdad6d77beea86b278b223743c.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3dd7329ac48ddd0a6b84412b9469a51',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/8b40dc7e6a38232e221b4ba3c4664785.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58c3813e9f26a73685115323b71bfe7b',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/a752e65a3d95104ebabe167165622023.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '509f8f93dd9e0a0abe3ab589f65d7d1d',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/773b7767e55547759f1c813d600721fb.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4d62e5f8ea70a28ce30f69380f1ae60',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/035841e8f13cc1748b726a701ad6f16e.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56779813b76e79f53abdcd6d8a716d9d',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/7df369dc3914d20b0f4ff3424429b6ad.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4166fa3aa64e7c7918dcc379df8e36fd',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/6cba8e7ad59c2191e287c9c852adf4b2.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '482ab192c4b4f83bfc0631cfee966b1c',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/bbf681fe6c8f67b9ff7341a2907be984.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54486efc59097489f430c352d4b37c4d',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/0c7b257fc4452fd5903c05965bdcc8b0.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c419079ba24e3e48382b3f1d1def1cdd',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/0762a414a0f4cdd2a597dfd403bfdeb1.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69fce13dc001d4e7dc3b4ef3eabe8635',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/efb7ac38e25311cb420347917a483c76.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0b5d744cc7d139ec5dfed0e692042c1',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/3f787727f181ff2fd4a91e8334e2f299.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '957fc0ef8a8a78fa2f0930319a4b9ec3',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/ed89e77c393be01df49b4725e7729f8d.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5750e33731eecc3a53a0a0da3d313291',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/83e7208b78a8168ffcb7a5abf3275a16.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '572f6f1764415d08abd6b8beefbb8f8c',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/d7ea6446cea207ed48c95d28c5db19df.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3859b3cf2993a6b4a5eccbf2d37a7ac3',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/bdea9bb636b5476dcc90d6045b7587be.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '717217db78f1df98db369ff273d00225',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/3bac169748ad9d52840f43969ded2bb3.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '107c554974bb9997f8fd91cab4fe40b9',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/e193d62aaad83e04aff011a3ad0e0125.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9537a0e56a078cb6592e76e3e315269f',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/d7195905d785dad613d9f7873c966aee.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94ab687fe4d6eb232ac6674a4831fbcd',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/21c1f9bc5b408f1f4c24adb4f5964907.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd1048a99c8caaae82513a6494def7be',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/59a1b2cadeef62d9717cb82095bdf8fa.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c7efa04142c2a9c1d5e1576a5d0eaec',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/b1bf1e18996ce4f1bfc413923863e01f.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7313cbe429e158d3d9ea0fc32c67e09',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/7199d079952c005bbc9a51582f0608ca.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0b2c2b5d3f026012a60018570afd986',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/b17d7950f47c5e5c39ead89f03976f40.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9acbf0a16971fdf90761430830acbb43',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/adec3990c8cf8fdae8ce265ac0d796eb.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30e675625fe58b04a53eddd5f735ceb0',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/40e53c4ca8b159d6c972a0f1a2a4d03a.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '012981b8481c3469146c01bc36cace26',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/f54b2c323ee913e38e27313e5e8f8d07.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9810f01bb64c272db47463c338350f7d',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/31fed88e7a8c1cf8839305f9fb7dc1c9.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29d6ca45c269eed4357e8a440b69b6ea',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/971327d6f3df4894ee78707bcb6a4b6d.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57137788fb7543e094159eff21d79e1a',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/fe3682891f0ebbd8fd668f1a51a27e39.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81d94e4e63f99244db17e6d2fd8d93f4',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/a497ae7f5127e951749224cfa22b17a9.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf7eaf1fbc55f8ae05ec5c47210e5271',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/7aeead3ae71763d66b468f9947d76045.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05dc928f50920cbcbff5bbc5a9ea54dc',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/6a106e3e2444efc2d8d85421deb3d07f.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45fa4fe08a9133bde473f51e94d0cf89',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/209455a722f096dc845ee5c4ec852b8d.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '242e867797ada15ddfc6504591fbf719',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/d914ac4d46c8c1e34fbc7026cbea2d55.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19e6b12bd237aca58bff33831ace2df2',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/016932f406c54a356d4d4149e9896974.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f0f16fffeb174c0ab69e267230c372d',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/4d74e538063c960642e9b3871c91f6de.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2acf44bff4ae45919ea47e09c9d5be11',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/310fb4cd796da2ce3c229d7e1d12a001.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d00de867712c056bf743d11da1ee555',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/585acaac6e1930a72422b82b0ec32fa6.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ebcddb330c322f647173779fcefcfc2b',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/6b37e221b03bb70a333bb7ae5d61fc7d.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '798d2c2ca7d5081ad1333777b8d895be',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/aad834b8746a993f18b0324ab29e2eaa.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8a0f22c4e18229e1247953cee45506f',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/0a924e1a6d19f2114be81391842ee0e8.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5664ee7ef66ef4bf8ee90cbb8004c4f',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/61cfc1c0e33c5caadb6639074eedd232.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b4e695722941bdcd96a948640cc2801',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/fc39d47d282de18eb605c1c422da9bdd.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77abb48b72b8975cf77033404e69a534',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/45adbd4ebdc433169ba3c90cec7bd0f4.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b327072e2f549c4412b2ccd6ce118610',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/6b50b55fb24ff80793e1e1e19d15fb95.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '425635c86c60b8969cce53dd93fc1cec',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/929c0bc2c5708afa78f9e79b0e025f0e.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd862b09a1d10350d4939cb038edcb13',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/d34f6dc053adc6a9c0ee898aae195701.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1fe7ef99c00c4c1d777705792565492',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/9889a3a51b52a0123a61863f0a1626d9.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3230e443eac373493b03a74d2d3109ef',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/8422abd2a1ada53c7f83cd3a1906571c.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4591e32413e9cdbd30fdac7257639b4c',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/bf59bc2799bfcfe13ae3051a3fa43e61.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84f3cb973ee4c00e11cbc2f231d40109',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/152785559d7dddcf7839a603b72b8d99.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c65cfa28bbb111a3c69969c562892eb',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/ffee8c3b1b2eb2bb033b1a077402128e.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e56e36c75df4672e0ec472e9fd323fb',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/40997d1fa8f5bd5b61dd1ac229bb6c1c.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e7d07a22411fbb974fa530752db771a',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/e36ce0929bcad9cd6ae4f8374fd9006c.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '623b1507311993a6d7793b9c186b2431',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/39ba97d8e8394e8bc8a7c83038b6dd82.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f524dbbcc06ca00b978bb368315e3c3f',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/59376c0e7c22f8c90ec2d5c84ac0c022.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5caeda66c28d1198985c5f29ccac562b',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/d6c8b7b482a3f08e365e60f4d3d31409.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ae94cc962ea1d5885a179a485a59864',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/754d0ac5b7412a892c228fabda581119.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40898e3fc6080a4be3f19feecd0a6ad3',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/4dd01e6534708f8288faf83bf2ac005a.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29930ebec6efc497cc4852bdd877d0ff',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/c15b68afe2f40bbe18f4837f7f66b06c.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed512b93a14660c794ddf820f1af8683',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/1211b61703a795adc06ea89848fda329.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc2bb01b7bf8a49a6a4e9c71eed90e10',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/40496da2d329d22150427c250a6135e1.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e986c85920407c9884e43c2e0f8ba64e',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/0c3c459f754d97f5cf71acdd13208615.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0723e5798ef8e2bb60f07ab219ca4040',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/3138eccaf307a70b4ab6a9120b61f120.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95357ff38cfe52b0ceece4989e082ee7',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/c44a4c59d30db4175a0daec843d7f8bd.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2407966818bfdb460e40a47359b26539',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/cbf966bbd68efcfef6c80a30043e8a9f.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7244f7f5d69015e125a12eacc2c95e0c',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/2e4888f84cb29f2fe6bb5fa119bd3897.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe1a27a67ea0512ead8a0c18fc976494',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/6dd73f4b314b3ca611ee3f5bad1b5990.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a62044d310c825cbea9dbc165ff4eaf3',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/a3d549659bd07a45efb78db78fdffaae.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73d3f50dd5de788c6e8d1abdbfac62e0',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/6f96e9e06ccdec96802b2b7bf3e9928b.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49af0fdddfbb62853248f379e9861535',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/68dcbb1222b573ff06674ea9012b3ac2.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a44bb1c55d4bb90ebc21689c8c1523f',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/d3fe4e0c8df1b796305c065bb8ae1367.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3307529623e37bbcaf8916c25332874e',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/b8f9e5ad2b0efb4d4e937cb90ba0b5a1.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e06a048df8b44839d76611e84b6ba80a',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/080c52255b1c9288cdae78d0c5c80305.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef70adad4aa0bcf8c93bdb66d4a33907',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/a34c2ea8b71ec165b777afe3728a156f.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a79d7791671528beb40f78625f279195',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/1758696efac22f2446105aab472c6f62.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a9533dec41f7bc50932b1b5ad189b0f',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/529a68bd84abf007c157939c804a7ba2.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f6fd5cbae302f9fb7ae34b197986566',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/f5a97ede64d53353276e2299483ee3bf.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '906b5aaa7f5066c89842dd1f557b8aab',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/12a674a6fdd86ac40be6f35fad7cf030.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cebe1bf2abe77284a45d4a46ee8eebe',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/b30ffea415dd56608c4fe4b31ce85cd5.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73c1a05a889522a859ea27a04d18a486',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/d71166680e2bbb1c1d13715811193050.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6fc8a2a5896487595fbe4200f400c755',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/0547ba4ef0d618c341ff117b350e4a4a.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c21242bcfdeb2d218f6fde2109906347',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/0e770b0b9e63ba08e37dd5a06d1c1227.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47e0e962660027263902b1e944672558',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/64373b7a2724c2921c2dc941e6b161f6.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aadec178f0b87a875de4e57ee2023c5d',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/acb8a6552f4b5b4420a8f6f4eea35bc3.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13392378a7136b774396a6b53cd8bece',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/cb82c0867019e00e3adb93a80b224fda.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13a3657c4192de488492e9a6a30e784b',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/fb6fadd3373f92891d16002a7397b630.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55567ec884b91f83e498823259d2ed08',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/4256c561591af432a3fd9bf6d6e8640a.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03d9d16fdb056b202dc70a5c4298ceca',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/3ec4a28c7d608c0c5adc9a05cb2234c7.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fda54086666895c8643a10bbac6fcdb',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/8c799f92d3b88d09b4dee2971a316c07.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a96009d90ffb6458d10b10913b83f9a2',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/41f025e3ea8a913bb5ca192db1e4a610.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '892c79a604f01ed41276d382b51442ae',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/198c03768bc8f0b20eb4638b59c3b1b9.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ede34b7717740482bede3ca9f40be2ea',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/7b1a736401a22f3e1f3282247dbfd58e.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7c15720c9eac3e7bd6632784e915f31',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/556f7835d289320dda83725a0b2ce6db.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1395891901d029c860a47a2c38c4fdc',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/934688e4968fe84dbceb5cb93787ea14.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4d3a091bd47817bc9526e3154bb8aa9',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/34ee88a2c7cdfcc3e0ad3d29d8a001f7.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc0d69824b1171c71a54aed64f6f3c2c',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/7ec767c951130e5bd62e4a43a4c07c2e.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e6f5327a82b665f2b6846f45ea92fd7',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/806e6fc1b223d3e357a23771180c06ae.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc53379f25ef8dc65e38da18f2586aee',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/a0c38443ed85e309e471fe0c8be9389d.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb0f3effc099537173766e9a4e32e319',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/1e62f6bf1b1548ba9d160283488fc960.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98f4a8846abb3dbc5963c847e7992189',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/8fcd3c074ff2671e63f4ab734e27063a.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ebcf8d1f14d0d8006eef368aef21503',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/687e5b81e35a8648464fd4c9ec85be8d.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f9b18d505616e1738451332da0afaf0',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/6553b55bfa9996b050a10c234cb32b9c.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '064776f196a8a44544abb435a03e6697',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/268bcfac383ef4996c80c1d142518dda.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c81c6df3aaf9131082c8cf3d855280c4',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/b3e3e256d6b21229a917702a16e896ee.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09d2bc87fdeb00101fd85a11d387d476',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/ab9df97d737fcf7ecca75f80785c28e9.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a5c1079602b955f2f1e561c5354a276',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/4cefe1796c52068aed153cac40d59722.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0f4ddd140f6f0c2e9f4a6e9a9f0324a',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/833ecff0c621fb1c0db90233a9704b90.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bec8280c983f0da55527daa7db181412',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/4ca8ff6c220da5883833cf56712de8e1.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b8e3edb160572e0a807c3ee725acc8a',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/8b78226039fda346aeecccce731a2d5c.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '111989e311e1aeb7ed31fc41a911ca3e',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/ddad8cd0dd5f8d6e73077fdea160fbff.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c21c13e4fb0a5a37524099177368b4b',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/ee1213ef69b08145bf1d243583514f84.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0f6913d18cae569a4f038bb54d162bd',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/e40196f171db36fee33fc6cc7e3869ba.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '760098af8d1d5bce43e3644fc63d773b',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/837be4442b3b4d0f4004cd0bc8529b59.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2388e3d6762bd06b5e7185d2ccf702f9',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/02a3579db6e668c9223e46562f79d7db.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f927e35d2dcb0c454ce3aff84da218a9',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/f1b9f77aacce810c38f8f23d2c6d7d41.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cad48ccdcfda6bc3021943e72b92b649',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/a4efedecea73a019fbea6ba325eceaea.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a547c08f3d1981baa95818ec767fc4fa',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/de633f677ddf559c236e37b7e39b847c.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23ea1e8ac6004c338500c5f199037f05',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/f69532bd10ec2b1a8b4fe745f70ed5e5.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'adb6092ce30013e30813fccec8315fec',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/2418bb473f4e15e9b486a50f528abdae.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '473b3ef43cab21e47928b4221364af50',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/b244135abf640e20489a96e7a5fb82c7.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc6e455ef48ba26b7b5430d1f1f87501',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/8f7e2fad0ec3df81e09341b0f0bf0e7e.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bec9fd6f588ed8d8ae25fa4ae63d139b',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/4824b620ed2bab61083d9068f15f92d2.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e44ee9df1e5f8fa53716c89a70dc0665',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/68b3436aa86173420b12bc1a75356499.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d5df21c58130f797d39aaa930a0cea8',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/15775a733a04bc63f7b1d1e709262fe7.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37e6f315453e28258bd5a305862606c2',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/1d6159dbba72a44c9e22a0abf74b614b.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2802f485698d538b88709dd1c1ac9389',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/c4d2555d8849fe89ff692587a6884251.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46937dc9378499452d99d1e20fb84745',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/1eb7bbe4c906f2b662c2a4747e210a4b.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2ba2b4b6286d0340c989eb580218103',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/a3b83f0984cdc0f1d9f16394cc1eeef0.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '866568b415fa7b114911182787c76cc4',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/0998bedef396bf250c24348389d72677.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '392eb2667e45c7473c4f3186dc52e614',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/37b24266ceb6d0d2fb15ba89a95ce801.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2005109336da10768c2a640a53768f41',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/1ad5299a264a1449d41001bd9d46f253.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '932a4630d6ec4b0ac99c13ebe05bfd6f',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/71fbc1501d142766448dfc85cd4d6312.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '066fdc6bc7fc54f74df5f066f8a6b390',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/981871815f2314bafd5fe90975144810.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29e94c8f76a4aadd4951935c59fe1813',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/24a634c108142ceb73168fd6cac40490.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c69bae2b02560119526fd374adb2bede',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/a2e4567cf3fff84f77c6b9bf122ff52d.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f160cadd1b96b421d1d9c7c5cee7e9f',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/a64bca67ffcfafa28b6719e1605392d9.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96f8d454f46f0ec0c8232819ef80e487',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/990d1047294f1b6e3c13616b4a8eccbb.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f992094ac43950f72aacbb25b814eb9',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/054b2d49bbed0e2981829f4c290a2380.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd933201c4bb2356efbe697027c2d5445',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/8e312b0d547fdb1a3fff72d0c4da63a6.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0e49985c7af5a22ab65eb7503151ba2',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/9e0c83bc7aa13b052d66f2f0ca677d5b.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebaaef15fbde7518284d7b6fc48ed443',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/aa8d025076663e0b7d11d036bbcce7ed.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b865a735961ac49ff741340abdc62013',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/cd079337598d0d86de2172112d895793.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f44c4214ca19ca9bc5f867832b07544a',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/5971855b6226409c48a5b6fe54910a1e.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fccf712a96cff6fe666f7f2ddf10b34',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/f52381fb9d8514b23cdad6bc779daa24.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '573a430b1ec95097961ec720bfb76862',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/085b0be3563e50660a3d43881558de43.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31381e76e54d3fa901d1cd6359215f46',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/8e73839860e4c4e60d0681edba2b107c.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0810a85fcf79ac42cbe591a2ef4c3506',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/8097d5ffc1f533c3d0385dcc6184d0eb.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0e8074d5e222578dadf050af61ce993',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/0359897bdb9f8ef9530886ff889e91c1.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '520295a9b50181ff3ab153b6f3fd920c',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/62c71c71addaf950b6dcb27dbe128a48.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6c0a2f543bdcb3a3ca8abb0641e396c',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/a23a374d67735aa6a096cf5d7e7c6146.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1388ffc14479b5aa2a35467941f88bba',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/409b9cf5d0a44fab69cc95b332ab854e.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43f5a503f229beae58ff9a0862889c5c',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/cbb270437ada7178386026e39cdf6677.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6b6316c291bc349c7cdb299719dfb67',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/852e5cd77233063784b206ccf65c9d4d.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed0f374d732c520e061953669ed18c6d',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/4e53bfe13302317a55a5fead3096b4ac.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51332675aa4afec3511e3c32df3ad7ea',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/bb964aa0240f00c25abf7d9b4f4d034e.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f380a975d93df3cfdeb8fa46d149f98a',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/95b8cc85949cc90626c8863e6474bbda.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b128b8bb73f9b15350004927dc01c462',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/3fac749e65193124a85d7e7c99a05657.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86e796134088d18eb5969bcb94517c8c',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/2568a2959ffac982e418ba2948bdbb1f.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '942a283f9689cadb416841aca35b8df0',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/acbe9c85b7145d661d3fd756a724f998.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'facfd90fc822c34756c85070720fdbdb',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/c9315eb41abbcfef40feac67f2d438bb.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8e690ac29bdec3b4e2a68a699a5df3c',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/56e9639611f4bcfa2b99bc83c84347bc.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9c6cdd41902faab7120517e7960385e',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/f3a582655d2f0fc31521608d1e1dc852.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4eb48f91e27d10d09d5232254ccc0f2d',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/fb7e681b6adfe3e451e02c0aacf28958.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '505bf333009c1721029531299d7d1f1a',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/de9c6ea39433fbd085ad629d0fabcbfb.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd817cd6e86ec77bc218ac48fe51caf70',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/73efee1ae6f437271d6915b512b5c2b2.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8788ce11350f47a073f3acdbc553256',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/93c550a5bf3ee2a4bb60f7a017b3609a.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d2a21b38dccac6dca4031b845667f9e',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/b7784ff63df4848f2b00160d0440b530.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06597a0c2e1e57079bea7ef53a5fb19a',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/65029a13a39fcbbec287c6e0d04bc994.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff094f35bc775c1df05839a6ac210fc8',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/d6793c6235477621913a45f8d50912c0.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ba48f9c059771e59f7f9d628a93f6b6',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/9155cb8c64ae2aa56375beee441968ce.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a94d6ee93578c53178e0b4bc3d8005b',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/a94c2ad093957aa59a07183ebce2b5b2.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aeedbac9a1eb9c9a4273322243216c30',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/a4af3dfefce4b0fa2b620e1b1da205a5.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1c470494440f42ee574f84af0e3b1ee',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/38759d4f551bd3d9b4337415e77acca3.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ede88b9e84a1582636340c553cb7d83',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/12235ab3ef8025e61917bce2463eea80.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af6e99343d16053e17b870f1077bce44',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/d003444484489a7160126462244fd12b.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af8576dc20764dbaa34cbf6b2abb0943',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/3170e84645aa7390d25686a88c6f51c4.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '563e585079ab368448e1cc156b62fc43',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/32b07c6781423d70aef52eb31daf5ea6.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c97967520f599bfa0cac64d1bd77807a',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/5cb2ed4d307332d6e22998cd26f0a440.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84cb2311e36ce0f64df268e191ef485d',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/80c0e65a82ab264497823dafab35be34.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14972a7bc8d9c893b737a54f06c4a28e',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/9a68f9dd55d9ab62728bb56e5edfac83.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2b064398ea4da444a0948b028d61717',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/211742a9a076485996a5b05347620e0f.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c7b80340ea1535e976bc67f56bd5bea',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/f5313256879971fe5eca03819447c88f.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0901b67742acc36be8fe8566fd74a4ef',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/ee251a9e0c79d065efdf02ea121381f8.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf4d80530de964efbc203732d761304c',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/21e52d41cd18b9f70798e8671b8db43c.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a89f1571a90fc9a78c8a98f2893be92',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/25169dfa196aede1cd950d6ba2b180a5.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f531aff8557b55472d50228036699c9a',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/c0661f8b52d6f3033c0f5eb6327bd9c7.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '060e0cb9564cb8534fb73ea74b0051f6',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/2be5c96a9bff210fa3e15e53d9a357b6.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79e1879286c74922dce904dbc97f43ea',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/8ea996bd794f5d04f78896c627a1ac61.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c050c1ceef770149496fa8eff5819179',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/46a4cd8e7411f7e232b8622aee460a5a.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2f7570bfd7bcff5a50804e1e018f71a',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/e9db299c03ce73958c6b1469ab89ced8.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c804ed2c198461d2d3ed4909e9eec07',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/d887257e7b19cc2c0bf5b686c1ebbc72.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b775422e6b278dbac86f8d6f0adb1ed8',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/5098e7492f6fcff6250128625014db4e.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ad40b1f9b47e61ddd0899a4c057a4bc',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/1c6c40fee6f5c51972d0df5ea6a645ae.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '071cfe4a1a5de28c5d980d63a5b93fa7',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/e06b370c4577e61b64a6f3ecabf81a56.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56805e619b1805c50cf791ae747080c2',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/b7bd4f25b10e49e96f1daf97cc0633cf.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c21ee0c376ec3293fa6455563d97da43',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/16f37dbc070325786b742e1ccd85a75d.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c5be928b79bf25f6d06852edd326165',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/0baf1d5ed930a4d2a02136e5c11104ae.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f16e470d270c968e166dd08f8cd6718b',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/447f1fd60143f635b00bf14c3d8f79ca.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86f9a21535997af717258d689097ba15',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/be1e6b915dab245b45a2ecdbdfc05e36.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '009a5488e25406dd0e3aa02702bf07e3',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/b833206605a68618164487411b276418.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b8c4782ae07fec3ef9ede0328f9f857',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/85028cbce3913d0939643ceb3db7e379.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb465c45e53db325efbc73bb4ed65277',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/26bb163808d84dfbd8ecb5297ba55216.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f902195ba0a188d0a31fe2ad5b04f645',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/30eeeac70492c944c49ced4566ed3b8b.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53d483728bd05d7697eee9fa31ee4b8d',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/c11a937d3b22dd525bba3fcd664261dd.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6244d92fc28be6af1bd83c1c4cd8c41c',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/7daa586d689dcd047ee99518f807ffe6.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c9ea10ca8ec636bd751121f4bf3a6cc',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/77f244e21a2af2008fef7d0d5bb1b324.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6910fea3cf4b14a17dc92a82d3292a23',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/0db57417bf2736c3593c25f6813f9830.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53355a3afa92ac02a5dbd308ba349333',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/f2056273eaf1ce28f7df62a0da5bf428.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0dac833bcb78eda73c89b4e93356e7c2',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/e5e1d71e2c6137e89fe3b9670c3550f5.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '952f90a2a67961200b545e6af27bb9c6',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/ae5e9794021d77e1946e1443dbaf5f54.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b01d69bb13d2c800f448a8eb6a726bb6',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/a13bb7f863a8408c5addb645da2233d8.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a1e5863d44a68358e14a315548db2b4',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/d7223f69dd4f8b08203e5726c6be12a4.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef228e6fe59f549811a9cd6533a25232',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/72c023a91a6ac67f093c344e9e6b48c7.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2eee7061ca692fb3ab7dd047840a0029',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/b6b986f8b277148269b0a69547384397.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5224b852d3ce842c2757e8fd863bd9f1',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/a5d2884c1fda48ec8b7656856fb71717.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcd50a6701d09de7c679a086fece9536',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/060e252f19a3cb657bd7c6b58d61ce6b.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f36bda52ef5a50bbcc0bbdf061be8d69',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/7d3925b8c2d7a7238db7093909633f16.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb06fce8e5460261150d673177047ab7',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/25cb1444d92c5376924e1854acae523a.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2fdc73b57126ebd37c838d8de11c74df',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/d5b2d1253eb03c253bccf697af8c23f8.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '884cb6025115296bc3e4122a5e007089',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/3fd6bdb2c252c3e966c0433be67ee6d1.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82997cd9b52bbeb7d4f39fdd42993ddc',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/20e8df0feeb271e93c91f35476911978.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed0bddb8d9a517363eaf70ed7199b066',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/add5dd95b9ee601c0e1b554c424e2b94.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa76cb76d521b44283b398b1a1537eb4',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/88bdca2dcc0da846dafcb506037651cd.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '212183a51bc2107aae0689fe4afcb7d2',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/08d292a1f1ae5ac0dc35cbfa4b3bf550.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '827c9a0136fb7e5b31c858d64054de94',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/d43c066e256b9dfc05c9da83da2d9944.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93d8adea309476a5280942de3d4b1c9c',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/dcbbaeac973deacb991a34035cec0f96.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '552d94d38161286df09b79c70f689628',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/ee38ff724fb81374a9157fdb860acb7b.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce386413596ab763d5096c8a7caaa720',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/9356b036ef2527c588fa632d9e00e1c1.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '831728f44c02df99ca40a13130a4266f',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/79b32ec9e2271a8c872c2717b23185bb.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24de7bd6ce3ff0a34ecca410ea3f909d',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/448f301831a1c14db0b4566f222f80ed.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f824c5e6601b98f7c0a5d96ff0d9df9',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/d8e74577d26e5acc68f355a7905c3b2f.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9dfdc1d50547105e7e64c193b7947334',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/cef752dafe30aed1c90a47ed20f248e8.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b90aac603b8c6da6d349c83d281c9e3e',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/26b9744beaca36d0b9b029dfaa4ccd14.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd64e6633e6f49d32dddab114230bf52b',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/0bd300b61748b5ba7a50c3a0de5c5d6f.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc13ee310ead321b9fa4246ed7476cdf',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/a712e16fc0e1cc3e035f62199e6773a0.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '369aa73e444554dc0fe3cecbcd7b8c2a',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/eb84c2ad2b11de81a630bd37bd2d8fdb.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2b73a28a9f9d66ffd1efe5e938e105f',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/01b1f0cca33a0d04c7cfb68b248f16ac.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44d664dc56c7f5fd46ae866161f212a4',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/a352805347284d81845488e9d51a0bdf.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca9f51fcf742794f6a17b1f5d8592a97',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/212a2b815d2731a83b28192001faa234.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77de0d2f2c93b557bef4adee83debe77',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/39977442ad2684752d62a98b9af9d5b6.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16c67149350ca9244948990bfde0d125',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/4ddebb2c77225d87cd4bcf7ffdf3870b.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc8bc3a9ffa02f8c3a37039f2e3a273c',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/d929ae4f88c5361afdebbbbb3882156b.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62b184ad21dab21efed48e86b1ae4fcc',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/a214c4d4832abfc6dc937e33f763f193.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00a580329edfcd59a7642c28992fd18a',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/b5f0d8d6fe7088708f9298ec3d10ef63.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4afdeb42c9b0c16c41b2f8495bfd6bc1',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/698ac1914613cef48c520cb6cf1d79fd.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b38ffb751e3a04eee1bed6a879a1c98',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/42c6d87ffee1fcf30cbb0c1c9cbfc725.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88cbc936c6efb4bdaa9d10951f0267c3',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/777b513ac8b679723b51e66562d09e66.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f633edace53c79fb663226fcbed0db44',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/e2a629382783baef8ce67e65cc83df90.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9407a2792e67a29d8f72e812344c3b34',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/2b2ce1599e99289b3e628db24319bd15.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f9fae1879ab2816a8567df33d439410',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/1a76de064ef35097cdc0cf0380186a60.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48716ee4570bae0ee435fc39d35def9d',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/43af93499d9d473808760b140ade9678.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fce469e8894682b75f52cc4dd0007cc2',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/25069d8a2173d8922986a0e84f4a7c5c.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bba1c513ebc2b1ebf89a0e45973afac7',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/c5ce136bf0e222e9de8a0a83254cd92c.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb06ab906a14332820c1a79b15ea6cb7',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/7c64f615ce9c441a6d1eff8b0f85025a.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'b88197c3c2a802832a7fc8dfcd9d5af5',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/bb2cc83435e14dffc98e85033a9bab16.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '7724078bc15519ef0e5fccb372b1d513',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/88df6cbaaed523268077bacb86a47228.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '07c300df68c7c4d63a19306badd78c30',
      'native_key' => 1,
      'filename' => 'modUserGroup/d11d670a003f62cdd8e91a0cd000e66b.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'ebe20e696a7d724d0e551c85594a217b',
      'native_key' => 1,
      'filename' => 'modDashboard/29ee80c143fe99a988913e8e96b4a11e.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '9b63d56f140074800780d92735393122',
      'native_key' => 1,
      'filename' => 'modMediaSource/d5ad33341b1b8a9a4ed461b1aaaa863a.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '522c0da52ad59b74af3f8cecc1e8881b',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/46441ba4b316213f3a4032ca806bb68d.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'ec0ee39f0a0a3899953db0104adf2661',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/38c009f35b1bc79de307501bb814306c.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'f6225dc295c7f8b21a09f3f67aa202e2',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/d7dfe43b9d9bd27a6a718254eb5c891f.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'e6e77d8ef43c6adcea6d35381f656bf2',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/4f838efaf9c63d12b6a00698b20e4e1e.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '320163413fd1c4082fa337fbab04dcaf',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/d8848b09ade47f311139630097a6548e.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'd798d9c82ac7a6d6c888e771de05a9aa',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/c11361b8c9853a48b22f28b9fe0ce746.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '073d38284014df3df3eaa698d099b6f2',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/1e0e2f4c3bc2a50db6ffecda7f3aa2d3.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '4bbc9f6f702bac0485137e0e8efee17c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/27ab606aede89443038789a856f8750c.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '61918489bc00b5997997e38d749c5043',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/54566a4efd094be82c23e17256bb5689.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '7789b42632395df7c6f72d03095c25ca',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/5886b81f59d8e9ddf985947714e18994.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '19d56a9336d973fa24d0a1cfce0fc293',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/1a3dccaedc8e96b803e53b9dced7bea2.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '39bd9dff9516ca39431bdbe578986416',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/34f1d5da0b31f3a3c41787aed9bd462a.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'a961ae3b3f09a11ed3c2ebad32cee18d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/766a2def83ad75754d22f05afc7f9c1a.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '7dfeaa2134859630903745f3c9254ea3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/43cf2bc0fda25e9fe320886912181b45.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '1772226cfd15b0493489f8d6e2d44df3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/f67e9f6bba419f4aedca88e5779dd1aa.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'bde713c2cb7138ebe7d5f0da4fbf843f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/96500738321146d20451bc72ac3a23a2.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'f769370488a2ef15b20813c79e6b0759',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/28ac2425edb5d56435c56f169e7ac445.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '369fdccb41d29fcb4d3ac36d03ed4bb7',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b017b679c16a008dee17233b52986a44.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '710c97577fc7078c1e7e9e7c8c4c1bd9',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/294f95799b31ffe455501af7cc26bb8c.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd554e2e6182dace54a333a155705f6e6',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/fee8de7bda45eb121ed788f56e921434.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'df014bd52100fb62aa6feabfd1791c11',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/9f3d96c3dbf83fbde8a6328eecd4a41f.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2513a010b5e8f776f8d336f14b7c62a3',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/6ceb46efed891ab72c28aec54100e2d9.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'aa7be8538e2008da8c950ddf89cfa053',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/eef74e0588daf2591826804fcda0bd5e.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c7c41f70285b954d69a8115f9454e870',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/a16bc161dcdfddfa652dea32d1d8e050.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a83ec932e60e08a1dfa7ecbf88a600a7',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/b9472441c1823312bc476657113e9696.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8ef1be80b0af072a9b7a2ed7be46cd92',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/7b16e04ad88f8b2842493aa0ea5119b4.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3dc08b864391311629218e7f22dd120a',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/2206af5ca18794762c2da446816e38bb.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f2b7c9ef11cb77a4548b4ee52bc86222',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/8e49394fda17621c7cdc08898b4f97ab.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ce1995aa5b8c6032e6a9c1dcfadc6f53',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/e507ad387f7edd4584def83dcb4d715a.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '9d46371c5bd7e0825dbfb33cfd499cda',
      'native_key' => 'web',
      'filename' => 'modContext/9d0af441d30a897a6c1923d1f793df9d.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '76ca41ff1e7879eb3562c48c0ce3e3c9',
      'native_key' => 'mgr',
      'filename' => 'modContext/ed79501f54b21b45b53a0154d41f0ee6.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e764183c349d9594134d85f3aa5942d7',
      'native_key' => 'e764183c349d9594134d85f3aa5942d7',
      'filename' => 'xPDOFileVehicle/444398e7fb63663a4a486bde718be594.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '5cc3d72d595001f8d9fc4f6837562da8',
      'native_key' => '5cc3d72d595001f8d9fc4f6837562da8',
      'filename' => 'xPDOFileVehicle/98240f2d9c053ef332281a23f76b72ef.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '0edd25f1e46b71b3e7e8d01624229eb4',
      'native_key' => '0edd25f1e46b71b3e7e8d01624229eb4',
      'filename' => 'xPDOFileVehicle/67a2ba3f43f7d8554da9213e5656af01.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '0313ccd9e6c310ea352d5070867661a3',
      'native_key' => '0313ccd9e6c310ea352d5070867661a3',
      'filename' => 'xPDOFileVehicle/2ff9eb0a2c7cd3188819cc2406e58745.vehicle',
    ),
  ),
);