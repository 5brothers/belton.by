<?php
$_lang['setting_protect_from_revaluation'] = 'Категории в которых нельзя выполнять переоценку';
$_lang['setting_protect_from_revaluation_desc'] = 'Список ID через запятую';
$_lang['setting_protected_parents'] = 'Ресурсы в дочерних категориях которых переоценка запрещена';
$_lang['setting_protected_parents_desc'] = 'Список ID через запятую';