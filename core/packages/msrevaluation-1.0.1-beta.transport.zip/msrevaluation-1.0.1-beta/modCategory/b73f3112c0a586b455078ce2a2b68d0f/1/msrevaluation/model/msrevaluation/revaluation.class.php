<?php
class Revaluation extends xPDOSimpleObject {}