<?php
    $_lang['all'] = 'All';
    $_lang['revaluation'] = 'Revaluation';
    $_lang['minishop2'] = 'miniShop2';
    $_lang['revaluation.management'] = 'Revaluations managment';
    $_lang['revaluation.revers'] = 'Revaluation reverse';
    $_lang['revaluation.revers.desc'] = 'Delete the  operation if you need cancel it';
    $_lang['id'] = 'ID';
    $_lang['comment'] = 'Comment';
    $_lang['time'] = 'Date';
    $_lang['rev_dir'] = 'Prices changes';
    $_lang['percent'] = 'Percent';
    $_lang['category'] = 'Category';
    $_lang['remove'] = 'Cancel this revaluatuion';
    $_lang['remove_confirm'] = 'Are you sure?';
    $_lang['not_loaded_class'] = 'msRevaluation class did not loaded';
    $_lang['new_revaluation'] = 'New revaluation';
    $_lang['buti_prices'] = 'Round to (rub.)';
    $_lang['help'] = 'Help';
    $_lang['help.text'] = file_get_contents(dirname(__FILE__).'/help.html');
    $_lang['increase'] = 'Increase';
    $_lang['decrease'] = 'Decrease';
    $_lang['empty_grid'] = $_lang['revaluation.desc'] = 'Right click in grid and choice "'.$_lang['new_revaluation'].'" to create new rewaluation';
    $_lang['vendor'] = 'Vendor';
?>