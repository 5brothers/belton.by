<?php
$_lang['setting_protect_from_revaluation'] = 'Category in which it is impossible to perform the revaluation';
$_lang['setting_protect_from_revaluation_desc'] = 'ID list, separated by commas';
$_lang['setting_protected_parents'] = 'Resources in child categories which reassessment is prohibited';
$_lang['setting_protected_parents_desc'] = 'ID list, separated by commas';