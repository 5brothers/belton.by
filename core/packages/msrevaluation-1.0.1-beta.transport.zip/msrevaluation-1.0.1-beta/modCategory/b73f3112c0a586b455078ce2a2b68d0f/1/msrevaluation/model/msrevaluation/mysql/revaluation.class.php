<?php
require_once (dirname(dirname(__FILE__)) . '/revaluation.class.php');
class Revaluation_mysql extends Revaluation {}