<?php
class mseAlias extends xPDOSimpleObject {}